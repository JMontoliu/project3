import base64
import functions_framework
from datetime import datetime
import os
import logging
import json
import psycopg2


logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")

PROJECT_ID  = os.getenv("PROJECT_ID", "default_project")
PG_DATABASE = os.getenv("PG_DATABASE", "default-db")
PG_USER = os.getenv("PG_USER", "user")
PG_PASSWORD =  os.getenv("PG_PASSWORD", "password")
PG_HOST = os.getenv("PG_HOST", "default_host")
PG_PORT = os.getenv("PG_PORT", "5432")

def get_postgres_connection():
    conn = psycopg2.connect(
        dbname=PG_DATABASE,
        user=PG_USER,
        password=PG_PASSWORD,
        host=PG_HOST,
        port=PG_PORT
    )
    create_table_if_not_exists(conn)
    return conn

def create_table_if_not_exists(conn):
    try:
        cursor = conn.cursor()
        create_table_query = """
    CREATE TABLE IF NOT EXISTS customers (
    id_persona VARCHAR(255) NOT NULL,
    nombre VARCHAR(255) NOT NULL,
    telefono VARCHAR(255) NOT NULL,
    fecha_reserva DATE NOT NULL,
    hora_reserva TIME NOT NULL,
    status VARCHAR(255) NOT NULL,
    created_at TIMESTAMP NOT NULL,
    PRIMARY KEY (id_persona)
    );
        """
        cursor.execute(create_table_query)
        conn.commit()
        cursor.close()
        logging.info("Table injured_players created (if it didn't exist).")
    except Exception as e:
        logging.error(f"Error creating table: {e}")
        raise


def insert_postgres(data):
    try:
        conn = get_postgres_connection()
        cursor = conn.cursor()

        insert_query = """
        INSERT INTO customers (id_persona, nombre, telefono, fecha_reserva, hora_reserva, status, created_at)
        VALUES (%s, %s, %s, %s, %s, %s, %s)
        ON CONFLICT (id_persona) DO UPDATE SET
            nombre = EXCLUDED.nombre,
            telefono = EXCLUDED.telefono,
            fecha_reserva = EXCLUDED.fecha_reserva,
            hora_reserva = EXCLUDED.hora_reserva,
            status = EXCLUDED.status,
            created_at = EXCLUDED.created_at
        """

        cursor.execute(insert_query, (
            data["id_persona"],
            data["nombre"],
            data["telefono"],
            data["fecha_reserva"],
            data["hora_reserva"],
            data["status"],
            data["created_at"]
        ))

        conn.commit()
        cursor.close()
        conn.close()
        logging.info("Data inserted into PostgreSQL.")
    except Exception as e:
        logging.error(f"Error inserting data PostgreSQL: {e}")
        raise

@functions_framework.cloud_event
def process_pubsub_message(cloud_event):
    try:
        data = json.loads(base64.b64decode(cloud_event.data["message"]["data"]).decode('utf-8'))
        
        if "created_at" not in data:
            data["created_at"] = datetime.now().isoformat()
        
        insert_postgres(data)
    except Exception as e:
        logging.error(f"Error trying to process register: {e}")
        raise